from groq import Groq

client = Groq(api_key="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")  


def get_llm_response(user_message):
    system_prompt = """
You are a compassionate mental health support assistant.
You are NOT a doctor.

Rules:
- Be empathetic
- Do not give medical diagnosis
- Encourage healthy coping strategies
- If user is in crisis, suggest seeking help
"""

    try:
        response = client.chat.completions.create(
            model="llama3-70b-8192",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message}
            ],
            temperature=0.7
        )

        return response.choices[0].message.content

    except Exception as e:
        return f"⚠️ LLM Error: {str(e)}"