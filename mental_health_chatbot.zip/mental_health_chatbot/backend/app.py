from flask import Flask, request, jsonify
from flask_cors import CORS

from llm import get_llm_response
from crisis_detector import detect_crisis

app = Flask(__name__)
CORS(app)


@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_message = data.get("message")

    # 🚨 Crisis check first
    if detect_crisis(user_message):
        return jsonify({
            "response": (
                "🚨 It looks like you're going through a very difficult time.\n\n"
                "Please consider talking to a trusted person or a mental health professional.\n"
                "You are not alone."
            )
        })

    # 🤖 LLM response
    reply = get_llm_response(user_message)

    return jsonify({"response": reply})


if __name__ == "__main__":
    app.run(debug=True)