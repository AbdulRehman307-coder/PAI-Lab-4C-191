def detect_crisis(message: str):
    message = message.lower()

    keywords = [
        "suicide", "kill myself", "end my life",
        "want to die", "self harm", "die"
    ]

    return any(word in message for word in keywords)