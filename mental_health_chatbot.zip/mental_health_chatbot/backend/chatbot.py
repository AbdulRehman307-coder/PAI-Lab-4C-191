def get_bot_response(user_message):

    user_message = user_message.lower()

    # simple mental health style responses
    if "stress" in user_message:
        return "I'm really sorry you're feeling stressed. Try taking deep breaths and take a short break."

    elif "anxiety" in user_message:
        return "Anxiety can feel overwhelming. Try grounding yourself: name 5 things you can see."

    elif "sad" in user_message:
        return "It's okay to feel sad sometimes. I'm here with you."

    elif "happy" in user_message:
        return "That's wonderful! I'm glad you're feeling better 😊"

    else:
        return "I'm here to listen. Can you tell me more about how you're feeling?"