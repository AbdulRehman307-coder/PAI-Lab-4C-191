import streamlit as st
import requests

st.set_page_config(page_title="Mental Health Chatbot")

st.title("🧠 AI Mental Health Chatbot")

if "chat" not in st.session_state:
    st.session_state.chat = []


user_input = st.text_input("How are you feeling today?")

if st.button("Send") and user_input:

    # send to backend
    response = requests.post(
        "http://127.0.0.1:5000/chat",
        json={"message": user_input}
    )

    bot_reply = response.json()["response"]

    # store chat
    st.session_state.chat.append(("You", user_input))
    st.session_state.chat.append(("Bot", bot_reply))


# show chat history
for sender, msg in st.session_state.chat:
    if sender == "You":
        st.markdown(f"**🧑 You:** {msg}")
    else:
        st.markdown(f"**🤖 Bot:** {msg}")