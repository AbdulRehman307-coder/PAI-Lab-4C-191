from flask import Flask, render_template, request
import requests

app = Flask(__name__)

API_KEY = "42jd48cw4Vlb48Q3BnjVrr82jSiLEgr7HUcuSoiw"  # <-- Put your API Ninjas key here

@app.route('/', methods=['GET', 'POST'])
def index():
    vehicle_data = None
    if request.method == 'POST':
        model = request.form['model']  # Get car model from user
        url = f"https://api.api-ninjas.com/v1/cars?model={model}"
        headers = {"X-Api-Key": API_KEY}
        response = requests.get(url, headers=headers)
        if response.status_code == 200 and response.json():
            # API returns a list of car(s)
            vehicle_data = response.json()[0]  # Get first result
        else:
            vehicle_data = {"Error": "Vehicle not found or invalid model"}
    return render_template('index.html', vehicle_data=vehicle_data)

if __name__ == '__main__':
    app.run(debug=True)